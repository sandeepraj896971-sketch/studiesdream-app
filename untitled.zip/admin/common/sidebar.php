<!-- Sidebar -->
<aside id="sidebar" class="w-64 bg-white h-[calc(100vh-60px)] fixed left-0 top-[60px] border-r border-gray-200 overflow-y-auto transform -translate-x-full lg:translate-x-0 transition-transform duration-300 z-40">
    <nav class="p-4 space-y-1">
        <?php
        $navs = [
            'index.php' => ['Dashboard', 'fas fa-chart-line'],
            'banner.php' => ['Banners', 'fas fa-images'],
            'course.php' => ['Courses', 'fas fa-graduation-cap'],
            'chapter.php' => ['Chapters', 'fas fa-list'],
            'video.php' => ['Videos', 'fas fa-video'],
            'notes.php' => ['Notes/PDFs', 'fas fa-file-pdf'],
            'notifications.php' => ['Notifications', 'fas fa-bell'],
            'mock_tests.php' => ['Mock Tests', 'fas fa-edit'],
            'current_affairs.php' => ['YouTube', 'fab fa-youtube text-red-600'],
            'books_notes.php' => ['E-Books & Notes', 'fas fa-book'],
            'live_classes.php' => ['Live Classes', 'fas fa-broadcast-tower'],
            'users.php' => ['Users', 'fas fa-users'],
            'orders.php' => ['Orders/Enroll', 'fas fa-cart-arrow-down'],
            'settings.php' => ['Payment & Contact Settings', 'fas fa-cog'],
            'app_settings.php' => ['App Configuration (UI/Links)', 'fas fa-paint-roller']
        ];
        $curr = basename($_SERVER['PHP_SELF']);
        foreach($navs as $url => $info):
            $active = ($curr == $url) ? 'bg-primary/10 text-primary font-bold border-r-4 border-primary' : 'text-gray-600 hover:bg-gray-50';
        ?>
        <a href="<?php echo $url; ?>" class="block px-4 py-3 flex items-center gap-3 transition-colors <?php echo $active; ?>">
            <i class="<?php echo $info[1]; ?> w-5 text-center"></i> <?php echo $info[0]; ?>
        </a>
        <?php endforeach; ?>
    </nav>
</aside>

<!-- Overlay for mobile sidebar -->
<div id="sidebar-overlay" onclick="toggleSidebar()" class="fixed inset-0 bg-black/50 z-30 hidden lg:hidden"></div>

<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        sidebar.classList.toggle('-translate-x-full');
        overlay.classList.toggle('hidden');
    }
</script>
