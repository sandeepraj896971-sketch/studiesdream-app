<?php
if(session_status() === PHP_SESSION_NONE) {
    session_start();
}
$host = '127.0.0.1';
$user = 'root';
$pass = 'root';
$db = 'studies_dream';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function checkAdmin() {
    if (!isset($_SESSION['admin_id'])) {
        header("Location: login.php");
        exit;
    }
}
?>
