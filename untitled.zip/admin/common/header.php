<?php
require_once 'config.php';
$stmt = $conn->prepare("SELECT app_name FROM settings LIMIT 1");
$stmt->execute();
$res = $stmt->get_result();
$settings = $res->fetch_assoc();
$app_name = $settings['app_name'] ?? 'Admin Panel';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - <?php echo htmlspecialchars($app_name); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: { colors: { primary: '#0284C7' } }
            }
        }
    </script>
</head>
<body class="bg-gray-100 text-gray-800">
    <!-- Navbar -->
    <header class="bg-primary text-white h-[60px] flex items-center justify-between px-6 sticky top-0 z-50">
        <div class="flex items-center gap-4">
            <button onclick="toggleSidebar()" class="lg:hidden text-2xl"><i class="fas fa-bars"></i></button>
            <h1 class="text-xl font-bold tracking-wide">ADMIN PANEL</h1>
        </div>
        <div>
            <a href="../index.php" target="_blank" class="text-sm bg-white/20 px-3 py-1 mr-2"><i class="fas fa-external-link-alt"></i> App</a>
            <a href="logout.php" class="text-sm bg-red-500 px-3 py-1"><i class="fas fa-sign-out-alt"></i></a>
        </div>
    </header>
    
    <div class="flex">
        <?php include 'sidebar.php'; ?>
        <main class="flex-1 p-6 lg:ml-64 min-h-[calc(100vh-60px)] relative overflow-x-hidden">
