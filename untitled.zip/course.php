<?php
require_once 'common/config.php';
include 'common/header.php';

$q = isset($_GET['q']) ? $conn->real_escape_string($_GET['q']) : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';

$where = "WHERE 1=1";
if ($q != '') {
    $where .= " AND title LIKE '%$q%'";
}
if ($type == 'free') {
    $where .= " AND is_free=1";
} elseif ($type == 'paid') {
    $where .= " AND is_free=0";
}

$courses = $conn->query("SELECT * FROM courses $where ORDER BY id DESC");
?>

<div class="px-4 py-4">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-lg font-bold">All Courses</h2>
    </div>

    <!-- Filters -->
    <div class="flex gap-2 mb-4 overflow-x-auto pb-2 scrollbar-none">
        <a href="course.php" class="px-4 py-1 text-sm border <?php echo $type==''?'bg-primary text-white border-primary':'bg-white text-gray-600 border-gray-200'; ?>">All</a>
        <a href="course.php?type=free" class="px-4 py-1 text-sm border <?php echo $type=='free'?'bg-primary text-white border-primary':'bg-white text-gray-600 border-gray-200'; ?>">Free</a>
        <a href="course.php?type=paid" class="px-4 py-1 text-sm border <?php echo $type=='paid'?'bg-primary text-white border-primary':'bg-white text-gray-600 border-gray-200'; ?>">Paid</a>
    </div>

    <div class="grid grid-cols-1 gap-4">
        <?php if($courses->num_rows > 0): while($c = $courses->fetch_assoc()): ?>
        <a href="course_detail.php?id=<?php echo $c['id']; ?>" class="flex flex-col bg-white border border-gray-100 rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.06)] overflow-hidden relative group transition hover:shadow-md">
            <div class="w-full aspect-video bg-gray-200 relative">
                <?php if($c['image']): ?>
                    <img src="uploads/courses/<?php echo htmlspecialchars($c['image']); ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <div class="w-full h-full flex items-center justify-center text-gray-400"><i class="fas fa-image text-3xl"></i></div>
                <?php endif; ?>
                <div class="absolute top-2 left-2 <?php echo $c['is_free'] ? 'bg-green-500' : 'bg-primary'; ?> text-white text-[10px] font-bold px-2 py-1 rounded-full uppercase z-10 shadow-sm">
                    <?php echo $c['is_free'] ? 'FREE' : 'PAID'; ?>
                </div>
            </div>
            <div class="p-4 flex flex-col flex-1">
                <h3 class="font-bold text-gray-800 mb-2 line-clamp-2"><?php echo htmlspecialchars($c['title']); ?></h3>
                <div class="flex items-center gap-2 mt-auto">
                    <?php if(!$c['is_free']): ?>
                        <span class="font-bold text-primary text-sm flex items-center">₹<?php echo floatval($c['price']); ?></span>
                        <?php if($c['mrp'] > $c['price']): ?>
                            <span class="text-xs text-gray-400 line-through">₹<?php echo floatval($c['mrp']); ?></span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="font-bold text-green-500 text-sm">Free</span>
                    <?php endif; ?>
                </div>
            </div>
        </a>
        <?php endwhile; else: ?>
            <div class="text-center py-10 text-gray-400">No courses found.</div>
        <?php endif; ?>
    </div>
</div>

<?php include 'common/bottom.php'; ?>
