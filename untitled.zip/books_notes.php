<?php
require_once 'common/config.php';
include 'common/header.php';

$q = isset($_GET['q']) ? $conn->real_escape_string($_GET['q']) : '';

$where = "WHERE 1=1";
if ($q != '') {
    $where .= " AND title LIKE '%$q%'";
}

$ebooks = $conn->query("SELECT * FROM ebooks $where ORDER BY id DESC");
?>
<div class="px-4 py-4">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-lg font-bold">Notes / E-Books</h2>
    </div>

    <div class="grid grid-cols-1 gap-4">
        <?php if($ebooks && $ebooks->num_rows > 0): while($c = $ebooks->fetch_assoc()): ?>
        <a href="ebook_detail.php?id=<?php echo $c['id']; ?>" class="flex bg-white border border-gray-100 shadow-sm overflow-hidden h-28 relative group shadow-sm transition hover:shadow-md">
            <div class="w-2/5 relative h-full bg-gray-200">
                <?php if($c['image']): ?>
                    <img src="uploads/courses/<?php echo htmlspecialchars($c['image']); ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <div class="w-full h-full flex items-center justify-center text-gray-400 border"><i class="fas fa-book text-3xl"></i></div>
                <?php endif; ?>
                <div class="absolute top-1 left-1 <?php echo $c['is_free'] ? 'bg-green-500' : 'bg-primary'; ?> text-white text-[10px] font-bold px-1.5 py-0.5 uppercase z-10 transition-transform group-hover:scale-105">
                    <?php echo $c['is_free'] ? 'FREE' : 'PAID'; ?>
                </div>
            </div>
            <div class="w-3/5 p-3 flex flex-col justify-between">
                <h3 class="font-bold text-gray-800 text-sm line-clamp-2"><?php echo htmlspecialchars($c['title']); ?></h3>
                <div class="flex items-center gap-2 mt-auto">
                    <?php if(!$c['is_free']): ?>
                        <span class="font-bold text-primary text-sm">₹<?php echo floatval($c['price']); ?></span>
                        <?php if($c['mrp'] > $c['price']): ?>
                            <span class="text-[10px] text-gray-400 line-through">₹<?php echo floatval($c['mrp']); ?></span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="font-bold text-green-500 text-sm">Free</span>
                    <?php endif; ?>
                </div>
            </div>
        </a>
        <?php endwhile; else: ?>
            <div class="text-center py-10 text-gray-400">
                <i class="fas fa-book text-gray-200 text-5xl mb-3"></i>
                <p>No E-books or Notes available yet.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php include 'common/bottom.php'; ?>
