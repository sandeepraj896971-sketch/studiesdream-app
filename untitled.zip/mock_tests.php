<?php
require_once 'common/config.php';
include 'common/header.php';

$subject_filter = isset($_GET['subject']) ? $conn->real_escape_string($_GET['subject']) : '';

$subj_query = $conn->query("SELECT DISTINCT subject FROM ext_mock_tests WHERE subject IS NOT NULL AND subject != '' ORDER BY subject ASC");
$subjects = [];
if ($subj_query) {
    while($row = $subj_query->fetch_assoc()) {
        $subjects[] = $row['subject'];
    }
}
?>
<div class="px-4 py-4">
    <h2 class="text-xl font-bold mb-3">Mock Tests</h2>
    
    <?php if(!empty($subjects)): ?>
    <div class="flex overflow-x-auto gap-2 pb-2 mb-3 scrollbar-hide">
        <a href="mock_tests.php" class="whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-bold border <?php echo empty($subject_filter) ? 'bg-primary text-white border-primary' : 'bg-gray-50 text-gray-600 border-gray-200'; ?>">All Tests</a>
        <?php foreach($subjects as $sub): ?>
        <a href="mock_tests.php?subject=<?php echo urlencode($sub); ?>" class="whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-bold border <?php echo $subject_filter === $sub ? 'bg-primary text-white border-primary' : 'bg-gray-50 text-gray-600 border-gray-200'; ?>"><?php echo htmlspecialchars($sub); ?></a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 gap-4 pb-20">
        <?php
        $where = "1=1";
        if (!empty($subject_filter)) {
            $where .= " AND subject='$subject_filter'";
        }
        
        $tests = $conn->query("SELECT * FROM ext_mock_tests WHERE $where ORDER BY id DESC");
        if($tests && $tests->num_rows > 0):
            while($t = $tests->fetch_assoc()):
        ?>
        <div class="bg-white p-4 rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.06)] border border-gray-100 flex flex-col relative overflow-hidden">
            <?php if(!empty($t['subject'])): ?>
            <div class="absolute top-0 right-0 bg-blue-50 text-blue-600 px-2 py-0.5 rounded-bl-lg text-[10px] font-bold uppercase tracking-wider">
                <?php echo htmlspecialchars($t['subject']); ?>
            </div>
            <?php endif; ?>
            <h3 class="font-bold text-gray-800 mb-1 pr-6"><?php echo htmlspecialchars($t['title']); ?></h3>
            <?php if($t['duration'] > 0): ?>
            <p class="text-xs text-gray-500 mb-2"><i class="far fa-clock mr-1"></i> <?php echo $t['duration']; ?> mins</p>
            <?php else: ?>
            <p class="text-xs text-gray-400 mb-2 mt-0.5">No time limit</p>
            <?php endif; ?>
            <div class="flex justify-between items-center mt-auto pt-3 border-t">
                <span class="text-sm font-bold <?php echo $t['is_free'] ? 'text-green-500' : 'text-primary'; ?>"><?php echo $t['is_free'] ? 'FREE' : '₹'.floatval($t['price']); ?></span>
                <a href="view_mock_test.php?id=<?php echo $t['id']; ?>" class="bg-primary text-white px-4 py-1.5 rounded border border-blue-600 text-sm font-bold shadow-sm hover:bg-blue-600 transition">Attempt Test</a>
            </div>
        </div>
        <?php endwhile; else: ?>
        <div class="text-center py-10 text-gray-500 col-span-full">No Mock Tests Available.</div>
        <?php endif; ?>
    </div>
</div>
<?php include 'common/bottom.php'; ?>
