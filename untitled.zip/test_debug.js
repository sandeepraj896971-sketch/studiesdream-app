console.log(process.cwd());
