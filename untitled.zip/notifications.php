<?php
require_once 'common/config.php';

if (isset($_SESSION['user_id'])) {
    $user_id = (int)$_SESSION['user_id'];
    $res = $conn->query("SELECT MAX(id) as max_id FROM app_notifications");
    $max_id = $res && $res->num_rows > 0 ? (int)$res->fetch_assoc()['max_id'] : 0;
    if ($max_id > 0) {
        $conn->query("UPDATE users SET last_read_notif_id = $max_id WHERE id = $user_id");
    }
}

include 'common/header.php';
?>

<div class="px-4 py-4">
    <h2 class="text-xl font-bold mb-4">Notifications</h2>
    <div class="space-y-3">
        <?php
        $notifs = $conn->query("SELECT * FROM app_notifications ORDER BY id DESC");
        if($notifs && $notifs->num_rows > 0):
            while($n = $notifs->fetch_assoc()):
        ?>
        <div class="bg-white p-3 rounded-lg shadow-sm border border-gray-100 flex gap-3">
            <div class="mt-1"><i class="fas fa-bell text-primary"></i></div>
            <div>
                <h3 class="font-semibold text-gray-800 text-sm"><?php echo htmlspecialchars($n['title']); ?></h3>
                <p class="text-xs text-gray-500 mt-1"><?php echo nl2br(htmlspecialchars($n['message'])); ?></p>
                <div class="text-[10px] text-gray-400 mt-2"><?php echo date('d M Y, h:i A', strtotime($n['created_at'])); ?></div>
            </div>
        </div>
        <?php 
            endwhile;
        else:
        ?>
        <div class="text-center text-gray-500 py-10">
            <i class="far fa-bell-slash text-4xl mb-2 text-gray-300"></i>
            <p>No notifications yet</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'common/bottom.php'; ?>
