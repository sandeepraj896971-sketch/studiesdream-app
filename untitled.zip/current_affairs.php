<?php
require_once 'common/config.php';
include 'common/header.php';
?>
<div class="px-4 py-4 pb-[80px]">
    <h2 class="text-xl font-bold mb-4 font-sans text-gray-800 border-l-4 border-red-600 pl-2">YouTube Videos</h2>
    <div class="grid grid-cols-1 gap-4">
        <?php
        $tests = $conn->query("SELECT * FROM ext_current_affairs ORDER BY id DESC");
        if($tests && $tests->num_rows > 0):
            while($t = $tests->fetch_assoc()):
                $img = $t['thumbnail'] ? "uploads/thumbnails/".htmlspecialchars($t['thumbnail']) : "assets/placeholder.png";
        ?>
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden flex flex-col relative group pb-3">
            <div class="w-full aspect-video bg-gray-200 relative">
                <img src="<?php echo $img; ?>" class="w-full h-full object-cover">
                <div class="absolute top-2 left-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">NEWS</div>
            </div>
            
            <div class="p-3">
                <h3 class="font-bold text-gray-900 text-sm leading-tight mb-2"><?php echo htmlspecialchars($t['title']); ?></h3>
                <span class="text-[10px] text-gray-400 font-medium tracking-wide flex items-center gap-1 mb-3">
                    <i class="fas fa-calendar-day text-gray-300"></i> <?php echo date('d M Y', strtotime($t['created_at'])); ?>
                </span>
                
                <div class="flex gap-2">
                    <?php if($t['video_url']): ?>
                    <a href="<?php echo htmlspecialchars($t['video_url']); ?>" target="_blank" class="flex-1 bg-red-50 text-red-600 font-bold py-1.5 rounded text-center text-xs border border-red-100 active:bg-red-100 transition-colors">
                        <i class="fab fa-youtube mr-1"></i> Watch
                    </a>
                    <?php endif; ?>
                    
                    <?php if($t['file_url']): ?>
                    <a href="pdf_viewer.php?url=<?php echo urlencode($t['file_url']); ?>" class="flex-1 bg-primary text-white font-bold py-1.5 rounded text-center text-xs active:bg-blue-700 transition-[transform,colors]">
                        <i class="fas fa-file-pdf mr-1"></i> Read PDF
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endwhile; else: ?>
        <div class="text-center py-10 bg-gray-50 rounded-xl border border-dashed border-gray-200 text-gray-400">
            <i class="fas fa-newspaper text-4xl mb-3 text-gray-300"></i>
            <p class="font-medium text-sm">No updates right now</p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php include 'common/bottom.php'; ?>
