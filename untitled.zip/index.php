<?php
require_once 'common/config.php';
include 'common/header.php';
?>

<!-- Slider -->
<div class="relative w-full px-3 pt-3" id="slider-container">
    <div class="relative w-full aspect-[16/10] bg-white rounded-xl overflow-hidden shadow-sm flex items-center justify-center border border-gray-100">
        <div id="slider" class="relative w-full h-full">
            <?php
            $banners = $conn->query("SELECT * FROM banners ORDER BY id DESC");
            if($banners->num_rows > 0):
                $first = true;
                $count = 0;
                while($b = $banners->fetch_assoc()):
                    $display = $first ? 'opacity-100' : 'opacity-0';
                    $first = false;
            ?>
            <div class="slide absolute inset-0 transition-opacity duration-500 <?php echo $display; ?>" data-index="<?php echo $count; ?>">
                <a href="<?php echo htmlspecialchars($b['link']); ?>">
                    <img src="uploads/banners/<?php echo htmlspecialchars($b['image']); ?>" class="w-full h-full object-fill">
                </a>
            </div>
            <?php 
                $count++;
                endwhile; 
            else: ?>
                <div class="flex items-center justify-center h-full text-gray-400 bg-gray-100">No Banners</div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Slider dots -->
    <div class="flex justify-center gap-[6px] mt-2 mb-1" id="slider-dots">
        <?php
        if (isset($count) && $count > 0) {
            for ($i = 0; $i < $count; $i++) {
                $bg = ($i == 0) ? 'bg-gray-500 w-2.5' : 'bg-gray-300 w-1.5';
                echo "<div class='h-1.5 rounded-full transition-all duration-300 $bg dot' data-index='$i'></div>";
            }
        }
        ?>
    </div>
</div>

<script>
    let slides = document.querySelectorAll('.slide');
    let dots = document.querySelectorAll('.dot');
    if(slides.length > 1) {
        let current = 0;
        setInterval(() => {
            slides[current].classList.replace('opacity-100', 'opacity-0');
            dots[current].classList.replace('bg-gray-500', 'bg-gray-300');
            dots[current].classList.replace('w-2.5', 'w-1.5');
            
            current = (current + 1) % slides.length;
            
            slides[current].classList.replace('opacity-0', 'opacity-100');
            dots[current].classList.replace('bg-gray-300', 'bg-gray-500');
            dots[current].classList.replace('w-1.5', 'w-2.5');
        }, 4000);
    }
</script>

<div class="px-3 py-3 max-w-md mx-auto">
    <style>
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }
        @keyframes gentle-pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        @keyframes wiggle {
            0%, 100% { transform: rotate(0deg); }
            25% { transform: rotate(-5deg); }
            75% { transform: rotate(5deg); }
        }
        .anim-float { animation: float 3s ease-in-out infinite; }
        .anim-pulse { animation: gentle-pulse 2.5s ease-in-out infinite; }
        .anim-wiggle { animation: wiggle 4s ease-in-out infinite; }
        .anim-spin-slow { animation: spin 8s linear infinite; }
    </style>
    <!-- Grid System -->
    <div class="grid grid-cols-2 gap-3">
        <!-- Paid Courses -->
        <a href="course.php?type=paid" class="bg-gray-50/50 rounded-xl shadow-[0_2px_4px_rgba(0,0,0,0.06)] py-6 px-2 flex flex-col items-center justify-center text-center border border-gray-200 active:bg-gray-100 transition-colors group">
            <div class="h-16 mb-3 flex items-center justify-center relative w-16 anim-float">
                <i class="fas fa-chalkboard-teacher text-[52px] text-[#2b7cff] group-hover:text-blue-600 transition-colors"></i>
                <div class="flex gap-1.5 absolute -bottom-1.5 anim-pulse">
                    <i class="fas fa-user text-[#ff4f4f] text-[16px]"></i>
                    <i class="fas fa-user text-[#10b981] text-[16px] mt-1"></i>
                    <i class="fas fa-user text-[#ff9800] text-[16px]"></i>
                </div>
            </div>
            <span class="font-bold text-gray-800 text-[14px]">Paid Courses</span>
        </a>

        <!-- MOCK TEST -->
        <a href="mock_tests.php" class="bg-gray-50/50 rounded-xl shadow-[0_2px_4px_rgba(0,0,0,0.06)] py-6 px-2 flex flex-col items-center justify-center text-center border border-gray-200 active:bg-gray-100 transition-colors group">
            <div class="h-16 mb-3 flex items-center justify-center relative w-16 group-hover:scale-105 transition-transform">
                <div class="w-[42px] h-[52px] border-2 border-gray-800 rounded bg-[#eff6ff] flex flex-col gap-1.5 p-1.5 items-start justify-center relative shadow-sm">
                    <div class="flex items-center gap-1"><div class="w-2.5 h-2.5 bg-green-500 rounded-sm border border-green-600 flex items-center justify-center"><i class="fas fa-check text-white text-[6px]"></i></div><div class="w-4 h-[3px] rounded bg-gray-400"></div></div>
                    <div class="flex items-center gap-1"><div class="w-2.5 h-2.5 border-2 border-gray-400 rounded-sm"></div><div class="w-4 h-[3px] rounded bg-gray-400"></div></div>
                    <div class="flex items-center gap-1"><div class="w-2.5 h-2.5 bg-green-500 rounded-sm border border-green-600 flex items-center justify-center"><i class="fas fa-check text-white text-[6px]"></i></div><div class="w-4 h-[3px] rounded bg-gray-400"></div></div>
                </div>
                <!-- Pencil overlay -->
                <i class="fas fa-pencil-alt text-yellow-500 text-[28px] absolute -right-4 -bottom-1 transform -rotate-45 drop-shadow-md z-10 anim-wiggle" style="text-shadow: 1px 1px 0 #333, -1px -1px 0 #333, 1px -1px 0 #333, -1px 1px 0 #333;"></i>
            </div>
            <span class="font-bold text-gray-800 text-[14px] uppercase">MOCK TEST</span>
        </a>

        <!-- Free PDFs -->
        <a href="free_pdfs.php" class="bg-gray-50/50 rounded-xl shadow-[0_2px_4px_rgba(0,0,0,0.06)] py-6 px-2 flex flex-col items-center justify-center text-center border border-gray-200 active:bg-gray-100 transition-colors group">
            <div class="h-16 mb-3 flex items-center justify-center relative w-16 anim-float" style="animation-delay: 1s;">
                <i class="fas fa-folder text-[58px] text-[#ffeb3b]" style="text-shadow: 0px 2px 2px rgba(0,0,0,0.1);"></i>
                <div class="absolute inset-0 flex flex-col items-center justify-center pt-2">
                    <div class="bg-white text-gray-800 text-[11px] font-extrabold px-1 rounded shadow-sm border border-gray-100">PDF</div>
                </div>
                <i class="fas fa-arrow-circle-down text-green-500 text-[28px] absolute -bottom-2 -right-1 bg-white rounded-full border border-white z-10 anim-pulse"></i>
            </div>
            <span class="font-bold text-gray-800 text-[14px]">Free PDFs</span>
        </a>

        <!-- YouTube -->
        <a href="current_affairs.php" class="bg-gray-50/50 rounded-xl shadow-[0_2px_4px_rgba(0,0,0,0.06)] py-6 px-2 flex flex-col items-center justify-center text-center border border-gray-200 active:bg-gray-100 transition-colors group">
            <div class="h-16 mb-3 flex items-center justify-center relative w-16 anim-pulse" style="animation-delay: 0.5s;">
                <i class="fab fa-youtube text-[58px] text-red-600" style="text-shadow: 0px 2px 2px rgba(0,0,0,0.1);"></i>
            </div>
            <span class="font-bold text-gray-800 text-[14px]">YouTube</span>
        </a>

        <!-- Notes / E-books -->
        <a href="books_notes.php" class="bg-gray-50/50 rounded-xl shadow-[0_2px_4px_rgba(0,0,0,0.06)] py-6 px-2 flex flex-col items-center justify-center text-center border border-gray-200 active:bg-gray-100 transition-colors group">
            <div class="h-16 mb-3 flex items-center justify-center relative w-16 anim-float" style="animation-delay: 1.5s;">
                <div class="w-[42px] h-[54px] bg-white border-2 border-gray-800 rounded relative shadow-sm flex flex-col gap-1.5 p-1 pt-4 items-center">
                    <div class="absolute -top-1.5 left-0 right-0 flex justify-evenly">
                        <div class="w-[4px] h-[12px] bg-yellow-400 rounded-full border border-gray-800"></div>
                        <div class="w-[4px] h-[12px] bg-yellow-400 rounded-full border border-gray-800"></div>
                        <div class="w-[4px] h-[12px] bg-yellow-400 rounded-full border border-gray-800"></div>
                        <div class="w-[4px] h-[12px] bg-yellow-400 rounded-full border border-gray-800"></div>
                    </div>
                    <div class="w-7 h-[3px] bg-gray-400 rounded"></div>
                    <div class="w-7 h-[3px] bg-gray-400 rounded"></div>
                    <div class="w-7 h-[3px] bg-gray-400 rounded"></div>
                    <div class="w-5 h-[3px] bg-gray-400 rounded self-start ml-1"></div>
                </div>
                <i class="fas fa-pencil-alt text-blue-500 text-[26px] absolute -left-4 -bottom-1 transform rotate-[220deg] drop-shadow-[1px_1px_1px_rgba(0,0,0,0.3)] z-10 anim-wiggle" style="text-shadow: 1px 1px 0 #333, -1px -1px 0 #333, 1px -1px 0 #333, -1px 1px 0 #333;"></i>
            </div>
            <span class="font-bold text-gray-800 text-[14px]">Notes / E-books</span>
        </a>


        <!-- Website Links -->
        <a href="website_links.php" class="bg-gray-50/50 rounded-xl shadow-[0_2px_4px_rgba(0,0,0,0.06)] py-6 px-2 flex flex-col items-center justify-center text-center border border-gray-200 active:bg-gray-100 transition-colors group">
            <div class="h-16 mb-3 flex items-center justify-center relative w-16 anim-pulse" style="animation-delay: 0.5s;">
                <i class="fas fa-mobile-alt text-[64px] text-gray-800"></i>
                <div class="absolute inset-0 flex flex-col items-center justify-center pt-2.5">
                    <div class="grid grid-cols-2 gap-1 mb-1 anim-float">
                        <?php if(!empty($app_settings['instagram_url'])): ?>
                            <i class="fab fa-instagram text-[14px] text-pink-500 font-bold border border-pink-200 rounded p-[1px] bg-pink-50"></i>
                        <?php else: ?><div></div><?php endif; ?>
                        
                        <?php if(!empty($app_settings['facebook_url'])): ?>
                            <i class="fab fa-facebook text-[14px] text-blue-600 font-bold border border-blue-200 rounded p-[1px] bg-blue-50"></i>
                        <?php else: ?><div></div><?php endif; ?>
                    </div>
                    <div class="grid grid-cols-2 gap-1 mb-2 anim-float" style="animation-delay: 0.3s;">
                        <div></div>
                        
                        <?php if(!empty($app_settings['youtube_url'])): ?>
                            <i class="fab fa-youtube text-[14px] text-red-600 font-bold border border-red-200 rounded p-[1px] bg-red-50"></i>
                        <?php else: ?><div></div><?php endif; ?>
                    </div>
                    <?php if(!empty($app_settings['whatsapp_url'])): ?>
                    <div class="absolute -bottom-1 -right-2 anim-wiggle">
                        <i class="fab fa-whatsapp text-[18px] text-white bg-green-500 rounded-full p-1 border-2 border-white shadow-sm"></i>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <span class="font-bold text-gray-800 text-[14px]">Website Links</span>
        </a>
    </div>
</div>

<!-- Dynamic Sections Below Categories -->
<div class="px-3 pb-[160px] max-w-md mx-auto space-y-5">
    
    <!-- Latest Courses Section -->
    <?php
    $latest_courses = $conn->query("SELECT * FROM courses ORDER BY id DESC LIMIT 5");
    if($latest_courses && $latest_courses->num_rows > 0):
    ?>
    <div class="mt-2">
        <div class="flex items-center justify-between px-1 mb-3">
            <h2 class="text-base font-bold text-gray-900 border-l-4 border-primary pl-2">Latest Courses</h2>
            <a href="course.php" class="text-xs font-bold text-primary bg-blue-50 px-2 py-1 rounded">View All</a>
        </div>
        
        <div class="flex overflow-x-auto gap-3 pb-2 snap-x snap-mandatory scrollbar-none" style="scroll-behavior: smooth; -ms-overflow-style: none; scrollbar-width: none;">
            <?php while($c = $latest_courses->fetch_assoc()): ?>
            <a href="course_detail.php?id=<?php echo $c['id']; ?>" class="snap-start shrink-0 w-[220px] bg-white border border-gray-100 rounded-xl shadow-sm overflow-hidden flex flex-col group">
                <div class="w-full h-[110px] bg-gray-200 relative overflow-hidden">
                    <?php if($c['image']): ?>
                        <img src="uploads/courses/<?php echo htmlspecialchars($c['image']); ?>" class="w-full h-full object-cover transition-transform group-hover:scale-105 duration-300">
                    <?php else: ?>
                        <div class="w-full h-full flex items-center justify-center text-gray-400 group-hover:scale-105 transition-transform"><i class="fas fa-image text-3xl"></i></div>
                    <?php endif; ?>
                    <div class="absolute top-2 left-2 <?php echo $c['is_free'] ? 'bg-green-500' : 'bg-primary'; ?> text-white text-[10px] font-bold px-1.5 py-0.5 rounded uppercase z-10 shadow-sm">
                        <?php echo $c['is_free'] ? 'FREE' : 'PAID'; ?>
                    </div>
                </div>
                <div class="p-3 flex flex-col justify-between flex-1">
                    <h3 class="font-bold text-gray-800 text-sm leading-snug line-clamp-2 mb-2 group-hover:text-primary transition-colors"><?php echo htmlspecialchars($c['title']); ?></h3>
                    <div class="flex items-center justify-between mt-auto">
                        <div class="flex items-center gap-1.5">
                            <?php if(!$c['is_free']): ?>
                                <span class="font-bold text-primary text-[15px]">₹<?php echo floatval($c['price']); ?></span>
                                <?php if($c['mrp'] > $c['price']): ?>
                                    <span class="text-[11px] text-gray-400 line-through">₹<?php echo floatval($c['mrp']); ?></span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="font-bold text-green-500 text-[15px]">Free</span>
                            <?php endif; ?>
                        </div>
                        <i class="fas fa-arrow-right text-gray-300 text-xs"></i>
                    </div>
                </div>
            </a>
            <?php endwhile; ?>
        </div>
    </div>
    <style>
    /* Hide scrollbar for Chrome, Safari and Opera */
    .scrollbar-none::-webkit-scrollbar { display: none; }
    </style>
    <?php endif; ?>

    <!-- Live Class Notification Banner -->
    <?php
    $res_live = $conn->query("SELECT * FROM live_classes WHERE is_active=1 ORDER BY id DESC LIMIT 1");
    if ($res_live && $res_live->num_rows > 0):
        $active_live = $res_live->fetch_assoc();
    ?>
    <div id="liveClassBanner" class="fixed bottom-[80px] left-1/2 -translate-x-1/2 w-full max-w-[calc(100%-24px)] md:max-w-[424px] bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden flex items-center p-3 z-50">
        <a href="live.php" class="flex-1 flex items-center gap-3 active:opacity-75 transition-opacity">
            <div class="w-14 h-14 rounded-full bg-red-50 border-2 border-red-500 flex items-center justify-center shrink-0 relative overflow-hidden">
                <?php if (!empty($active_live['thumbnail'])): ?>
                    <img src="uploads/thumbnails/<?php echo htmlspecialchars($active_live['thumbnail']); ?>" class="w-full h-full object-cover">
                <?php else: ?>
                    <i class="fas fa-satellite-dish text-red-500 text-xl pl-[1px]"></i>
                <?php endif; ?>
                <div class="absolute inset-0 bg-red-500/10 anim-pulse z-10 pointer-events-none"></div>
            </div>
            
            <div class="flex flex-col pr-8">
                <h4 class="font-bold text-gray-900 text-sm leading-tight line-clamp-2"><?php echo htmlspecialchars($active_live['title']); ?></h4>
                <div class="mt-1 flex items-center">
                    <span class="flex items-center gap-1 text-[10px] font-bold text-red-600 bg-red-100 px-1.5 py-0.5 rounded shadow-sm">
                        <span class="block w-1.5 h-1.5 bg-red-600 rounded-full anim-pulse"></span> LIVE
                    </span>
                </div>
            </div>
        </a>
        
        <div class="flex items-center gap-2">
            <a href="live.php" class="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg hover:bg-blue-700 hover:scale-105 transition-all text-sm pl-[3px]">
                <i class="fas fa-play"></i>
            </a>
            
            <button onclick="document.getElementById('liveClassBanner').style.display='none'" class="w-6 h-6 rounded-full bg-gray-100 text-gray-500 flex flex-col items-center justify-center hover:bg-gray-200 ml-1">
                <i class="fas fa-times text-xs"></i>
            </button>
        </div>
    </div>
    <?php endif; ?>

</div>

<?php include 'common/bottom.php'; ?>
