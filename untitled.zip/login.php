<?php
require_once 'common/config.php';
// Handle ajax request inline
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';
    if ($action === 'login') {
        $email = $conn->real_escape_string($_POST['email']);
        $password = $_POST['password'];
        $stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0) {
            $user = $res->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid password']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Email not found']);
        }
    } elseif ($action === 'signup') {
        $name = $conn->real_escape_string($_POST['name']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $email = $conn->real_escape_string($_POST['email']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        
        // check exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $check = $stmt->get_result();
        if ($check->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'Email already registered']);
        } else {
            $stmt = $conn->prepare("INSERT INTO users (name, phone, email, password) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $phone, $email, $password);
            if ($stmt->execute()) {
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['user_name'] = $name;
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Database error']);
            }
        }
    }
    exit;
}

include 'common/header.php'; 
?>

<div class="px-4 py-8 max-w-md mx-auto">
    <div class="bg-white p-6 shadow-sm mb-6 border border-gray-100">
        <!-- Tabs -->
        <div class="flex mb-6 border-b border-gray-200">
            <button onclick="switchTab('login')" id="tab-login" class="flex-1 py-2 font-bold text-primary border-b-2 border-primary">Login</button>
            <button onclick="switchTab('signup')" id="tab-signup" class="flex-1 py-2 font-bold text-gray-400">Sign Up</button>
        </div>

        <div id="msg" class="hidden p-3 mb-4 text-sm text-center text-white bg-red-500"></div>

        <!-- Login Form -->
        <form id="form-login" onsubmit="submitForm(event, 'login')">
            <input type="hidden" name="action" value="login">
            <div class="mb-4">
                <input type="email" name="email" placeholder="Email Address" required class="w-full p-3 bg-gray-50 border border-gray-200 outline-none focus:border-primary">
            </div>
            <div class="mb-4">
                <input type="password" name="password" placeholder="Password" required class="w-full p-3 bg-gray-50 border border-gray-200 outline-none focus:border-primary">
            </div>
            <button type="submit" class="w-full bg-primary text-white py-3 font-bold mt-2">LOGIN</button>
        </form>

        <!-- Signup Form -->
        <form id="form-signup" class="hidden" onsubmit="submitForm(event, 'signup')">
            <input type="hidden" name="action" value="signup">
            <div class="mb-4">
                <input type="text" name="name" placeholder="Full Name" required class="w-full p-3 bg-gray-50 border border-gray-200 outline-none focus:border-primary">
            </div>
            <div class="mb-4">
                <input type="text" name="phone" placeholder="Phone Number" required class="w-full p-3 bg-gray-50 border border-gray-200 outline-none focus:border-primary">
            </div>
            <div class="mb-4">
                <input type="email" name="email" placeholder="Email Address" required class="w-full p-3 bg-gray-50 border border-gray-200 outline-none focus:border-primary">
            </div>
            <div class="mb-4">
                <input type="password" name="password" placeholder="Password" required class="w-full p-3 bg-gray-50 border border-gray-200 outline-none focus:border-primary">
            </div>
            <button type="submit" class="w-full bg-primary text-white py-3 font-bold mt-2">SIGN UP</button>
        </form>
    </div>
</div>

<script>
    function switchTab(tab) {
        document.getElementById('msg').classList.add('hidden');
        if (tab === 'login') {
            document.getElementById('form-login').classList.remove('hidden');
            document.getElementById('form-signup').classList.add('hidden');
            document.getElementById('tab-login').classList.replace('text-gray-400', 'text-primary');
            document.getElementById('tab-login').classList.add('border-b-2', 'border-primary');
            document.getElementById('tab-signup').classList.replace('text-primary', 'text-gray-400');
            document.getElementById('tab-signup').classList.remove('border-b-2', 'border-primary');
        } else {
            document.getElementById('form-signup').classList.remove('hidden');
            document.getElementById('form-login').classList.add('hidden');
            document.getElementById('tab-signup').classList.replace('text-gray-400', 'text-primary');
            document.getElementById('tab-signup').classList.add('border-b-2', 'border-primary');
            document.getElementById('tab-login').classList.replace('text-primary', 'text-gray-400');
            document.getElementById('tab-login').classList.remove('border-b-2', 'border-primary');
        }
    }

    function submitForm(e, action) {
        e.preventDefault();
        const form = document.getElementById('form-' + action);
        const data = new FormData(form);
        const msgDiv = document.getElementById('msg');
        
        fetch('login.php', {
            method: 'POST',
            body: data
        })
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                window.location.href = 'index.php';
            } else {
                msgDiv.innerHTML = data.message;
                msgDiv.classList.remove('hidden');
            }
        }).catch(err => {
            msgDiv.innerHTML = 'An error occurred';
            msgDiv.classList.remove('hidden');
        });
    }
</script>

<?php include 'common/bottom.php'; ?>
